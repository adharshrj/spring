import MyAdminDashboard from './Admin Dashboard/MyAdminDashboard'
import {Route} from 'react-router-dom'
<Route exact path="./Admin Dashboard/MyAdminDashboard">
    <MyAdminDashboard/>
</Route>