import React from 'react'
import AdminSidebar from './Sidebar/AdminSidebar'
export default function MyAdminDashboard() {
    return (
        <div>
       
            <AdminSidebar/> <h1>WELCOME ADMINISTRATOR</h1>
        </div>
    )
}
