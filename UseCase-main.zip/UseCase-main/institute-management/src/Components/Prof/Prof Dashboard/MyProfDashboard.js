import React from 'react'
import ProfSidebar from './Sidebar/ProfSidebar'
export default function MyProfDashboard() {
    return (
        <div>
           <h1>WELCOME PROFESSOR</h1>
            <ProfSidebar/> 
            </div>
    )
}
