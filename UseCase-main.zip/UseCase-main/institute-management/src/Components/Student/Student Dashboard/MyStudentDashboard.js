 import React from 'react'
 import StudentSidebar from './Sidebar/StudentSidebar'
 export default function MyStudentDashboard() {
     return (
         <div>
            <StudentSidebar/> 
         </div>
     )
 }
 