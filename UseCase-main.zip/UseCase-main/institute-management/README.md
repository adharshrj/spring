# institute-management
 **Use Case**
1) Home page Created.
2) Navigation Bar created.
3) Footer created.
4) Login page for admin, professors and student has been completed.
5) Dashboard page for admin, professors and student has been created
6) Dashboard Sidebar for admin, orifessors and student has been completed.
7) Bootstrap has been added to all pages.
