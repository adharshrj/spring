package com.usecase.institutemanagements.controller;
public abstract class BaseController {
    
}