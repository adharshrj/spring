package com.usecase.institutemanagements.model;
public enum ARole {
	ROLE_STUDENT,
    ROLE_PROF,
    ROLE_ADMIN
}
